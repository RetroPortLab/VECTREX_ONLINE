Copy BOTH files in this zip into the ROOT folder of the UVMC2 cartridge SD card (not a subfolder):

  - the .um2 game
  - MONITOR.BIN  (the USB monitor the game loads when it starts; without it the cartridge never shows up on USB and Netlink cannot connect)

Then start the game from the multicart menu.
